﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Principal;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Customer_Account
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private List<CustomerAccount> accounts = new List<CustomerAccount>(); //call class for array list
        private int currentArrayIndex = 0;
        static int accNo = 0; //general accessible
        static double balance = 0.0;
        public MainWindow()
        {
            InitializeComponent();
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            Save();
        }
        private void PrevButton_Click(object sender, RoutedEventArgs e)
        {
            currentArrayIndex--;
            if (currentArrayIndex < 0)
            {
                currentArrayIndex = accounts.Count - 1;
            }

            FirstNameTextBox.Text = accounts[currentArrayIndex].getFirstName();
            LastNameTextBox.Text = accounts[currentArrayIndex].getLastName();
            AccountNumberTextBox.Text = accounts[currentArrayIndex].getAccountNumber().ToString();
            BalanceTextBox.Text = accounts[currentArrayIndex].getBalance().ToString();
        }

        private void NextButton_Click(object sender, RoutedEventArgs e)
        {
            if (!isNewRecord())
            {
                currentArrayIndex++;
                currentArrayIndex %= accounts.Count;
                FirstNameTextBox.Text = accounts[currentArrayIndex].getFirstName();
                LastNameTextBox.Text = accounts[currentArrayIndex].getLastName();
                AccountNumberTextBox.Text = accounts[currentArrayIndex].getAccountNumber().ToString();
                BalanceTextBox.Text = accounts[currentArrayIndex].getBalance().ToString();
            }
            else
            {
                Save();
            }
        }

        private void AddNewButton_Click(object sender, RoutedEventArgs e)
        {
            ClearWindow();
        }

        private void DelButton_Click(object sender, RoutedEventArgs e)
        {
            if (accounts.Count() > 0)
            {
                accounts.RemoveAt(currentArrayIndex);
                currentArrayIndex--;
                if (currentArrayIndex < 0)
                {
                    currentArrayIndex = accounts.Count - 1;
                }

                FirstNameTextBox.Text = accounts[currentArrayIndex].getFirstName();
                LastNameTextBox.Text = accounts[currentArrayIndex].getLastName();
                AccountNumberTextBox.Text = accounts[currentArrayIndex].getAccountNumber().ToString();
                BalanceTextBox.Text = accounts[currentArrayIndex].getBalance().ToString();
            }

        }
        private Boolean isNewRecord()
        {
            bool isNewRecord = true;
            int.TryParse(AccountNumberTextBox.Text, out accNo);
            for (int i = 0; i < accounts.Count; i++)
            {
                if (accounts[i].getAccountNumber() == accNo)
                {
                    isNewRecord = false;
                }
            }
            return isNewRecord;
        }
        private void Save()
        {
            if (!FirstNameTextBox.Text.Equals("") && !LastNameTextBox.Text.Equals("") && int.TryParse(AccountNumberTextBox.Text, out accNo) && double.TryParse(BalanceTextBox.Text, out balance))
            {
                CustomerAccount account = new CustomerAccount(FirstNameTextBox.Text, LastNameTextBox.Text, accNo, balance);
                if (isNewRecord())
                {
                    accounts.Add(account);
                    currentArrayIndex++;
                    MessageBox.Show("Account saved!");
                }
                else
                {
                    MessageBox.Show("Account duplicate exists!");
                    ClearWindow();
                }
            }
        }
        private void ClearWindow()
        {
            FirstNameTextBox.Text = "";
            LastNameTextBox.Text = "";
            AccountNumberTextBox.Text = "";
            BalanceTextBox.Text = "";
        }
    }
}
