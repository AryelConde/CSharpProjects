﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Documents;

namespace Customer_Account
{
    internal class CustomerAccount
    {
        
        private string firstName;
        private string lastName;
        private int accNo;
        private double bal;

        public CustomerAccount()
        {
            
        }
        public CustomerAccount(string firstName, string lastName, int accNo, double bal)
        {
            this.firstName = firstName;
            this.lastName = lastName;
            this.accNo = accNo;
            this.bal = bal;
        }

        public void setFirstName(string FirstName)
        {
            this.firstName = FirstName;
        }
        public string getFirstName()
        {
            return this.firstName;
        }

        public void setLastName(string LastName)
        {
            this.lastName = LastName;
        }
        public string getLastName()
        {
            return this.lastName;
        }
        public void setAccountNumber(int AccNo)
        {
            this.accNo = AccNo;
        }
        public int getAccountNumber()
        {
            return this.accNo;
        }
        public void setBalance(double Balance)
        {
            this.bal = Balance;
        }
        public double getBalance()
        {
            return this.bal;
        }
    }
}
