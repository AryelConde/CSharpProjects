﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace _255MTAVillacampo
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void CalculateButton_Click(object sender, RoutedEventArgs e)
        {
            double NewTicketPrice = 0, OrigTicketPrice = 0, DistTraveled = 0; //variables for the method parameters


            TicketCalculation(OrigTicketPrice, DistTraveled, NewTicketPrice); //call the building code for the method
        }
        private void TicketCalculation(double OrigTicketPrice, double DistTraveled, double NewTicketPrice) //parameters
        {
            double Discount;

            //if original ticket price does not equal to empty string, execute the code. Else, print error message.
            if (!OrigTicketPrice.Equals("") && Double.TryParse(OriginalPriceTextBox.Text, out OrigTicketPrice))
            {
                OrigTicketPrice = (OrigTicketPrice >= 0) ? OrigTicketPrice : 0;
                //if original ticket value is greater than 0 or it's true, get original ticket value - otherwise set default value to 0
                if (DistTraveled <= 1000)
                {
                    Discount = OrigTicketPrice * 0.01;
                    NewTicketPrice = OrigTicketPrice - Discount; //formula to get the new ticket price
                }
                else if (DistTraveled >= 1000 && DistTraveled <= 1500)
                {
                    Discount = OrigTicketPrice * 0.03;
                    NewTicketPrice = OrigTicketPrice - Discount;
                }
                else if (DistTraveled >= 1500 && DistTraveled <= 2000)
                {
                    Discount = OrigTicketPrice * 0.06;
                    NewTicketPrice = OrigTicketPrice - Discount;
                }
                else if (DistTraveled >= 2000 && DistTraveled <= 5000)
                {
                    Discount = OrigTicketPrice * 0.1;
                    NewTicketPrice = OrigTicketPrice - Discount;
                }
                else if (DistTraveled >= 5000)
                {
                    Discount = OrigTicketPrice * 0.15;
                    NewTicketPrice = OrigTicketPrice - Discount;
                }

                if (!DistTraveled.Equals("") && Double.TryParse(DistanceTraveledTextBox.Text, out DistTraveled))
                {
                    DistTraveled = (DistTraveled >= 0) ? DistTraveled : 0;
                    //if distance travelled value is greater than 0 or it's true, get distance travelled value - otherwise set default value to 0
                    if (DistTraveled <= 1000)
                    {
                        Discount = OrigTicketPrice * 0.01;
                        NewTicketPrice = OrigTicketPrice - Discount;
                    }
                    else if (DistTraveled >= 1000 && DistTraveled <= 1500)
                    {
                        Discount = OrigTicketPrice * 0.03;
                        NewTicketPrice = OrigTicketPrice - Discount;
                    }
                    else if (DistTraveled >= 1500 && DistTraveled <= 2000)
                    {
                        Discount = OrigTicketPrice * 0.06;
                        NewTicketPrice = OrigTicketPrice - Discount;
                    }
                    else if (DistTraveled >= 2000 && DistTraveled <= 5000)
                    {
                        Discount = OrigTicketPrice * 0.1;
                        NewTicketPrice = OrigTicketPrice - Discount;
                    }
                    else if (DistTraveled >= 5000)
                    {
                        Discount = OrigTicketPrice * 0.15;
                        NewTicketPrice = OrigTicketPrice - Discount;
                    }
                }
            }
            else
            {
                MessageBox.Show("Please input positive numerical values!");
            }
            NewPriceOutputTextBox.Text = "$" + Convert.ToString(NewTicketPrice);
        }

        private void OriginalPriceTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void DistanceTraveledTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void NewPriceOutputTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }
    }
}
