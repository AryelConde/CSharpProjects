﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace LoanRepaymentCalculator
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void CalculateButton_Click(object sender, RoutedEventArgs e)
        {
            decimal LoanPrincipal, MonthlyPayment, AnnualInterestRate, NumberOfMonths;
            decimal MonthlyInterest, Balance;
            decimal ExtraPaymentFrequency, ExtraPaymentAmount;

            string OutputTable = "", OutputRow = "";

            LoanPrincipal = Convert.ToDecimal(LoanPrincipalTextBox.Text);
            MonthlyPayment = Convert.ToDecimal(MonthlyPaymentTextBox.Text);
            AnnualInterestRate = Convert.ToDecimal(AnnualInterestTextBox.Text);
            NumberOfMonths = Convert.ToDecimal(NumberOfMonthsTextBox.Text);
            ExtraPaymentFrequency = Convert.ToDecimal(ExtraPaymentFrequencyTextBox.Text);
            ExtraPaymentAmount = Convert.ToDecimal(ExtraPaymentAmountTextBox.Text);

            OutputTable = "Month        Payment         Extra         Interest         Balance\n";
            OutputTable += "=========================================\n";
            OutputTable += "\t\t\t\t\t        " + LoanPrincipal +"\n";
            Balance = LoanPrincipal;
            int Month = 0;
            do
            {
                Month++;
                MonthlyInterest = Balance * AnnualInterestRate / 100 / 12; 
                if (Month % ExtraPaymentFrequency == 0)
                {
                    Balance -= MonthlyPayment + ExtraPaymentAmount - MonthlyInterest;
                    OutputRow = $"{Month}" + "                " + $"{MonthlyPayment:C2}" + "         " + $"{ExtraPaymentAmount:C2}" + "       " + $"{MonthlyInterest:F2}" + "             " + $"{Balance:C2}";
                    OutputTable += OutputRow + "\n";
                }
                else
                {
                    Balance += MonthlyInterest - MonthlyPayment;
                    OutputRow = $"{Month}" + "                " + $"{MonthlyPayment:C2}" + "                             " + $"{MonthlyInterest:F2}" + "             " + $"{Balance:C2}";
                    OutputTable += OutputRow + "\n";
                }
            }while (Month < NumberOfMonths);
            OutputTextBox.Text = OutputTable;
        }




        private void ExtraPaymentFrequency_TextChanged(object sender, TextChangedEventArgs e)
        {

        }
        private void ExtraPaymentAmount_TextChanged(object sender, TextChangedEventArgs e)
        {

        }
    }
}
