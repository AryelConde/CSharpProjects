﻿    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using System.Windows;
    using System.Windows.Controls;
    using System.Windows.Data;
    using System.Windows.Documents;
    using System.Windows.Input;
    using System.Windows.Media;
    using System.Windows.Media.Imaging;
    using System.Windows.Navigation;
    using System.Windows.Shapes;

namespace Lab2_InvoiceTaxShipping
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void CheckBox_Checked(object sender, RoutedEventArgs e)
        {

        }
        string userInput;
        private void Item1TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void Item2TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void Item3TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void Item4TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void SubtotalTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }
        private void ShippingTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void PSTTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void GSTTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void TotalTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void Item1CheckBoxPST_Checked(object sender, RoutedEventArgs e)
        {

        }

        private void Item1CheckBoxGST_Checked(object sender, RoutedEventArgs e)
        {

        }

        private void Item2CheckBoxPST_Checked(object sender, RoutedEventArgs e)
        {

        }

        private void Item2CheckBoxGST_Checked(object sender, RoutedEventArgs e)
        {

        }

        private void Item3CheckBoxPST_Checked(object sender, RoutedEventArgs e)
        {

        }

        private void Item3CheckBoxGST_Checked(object sender, RoutedEventArgs e)
        {

        }

        private void Item4CheckBoxPST_Checked(object sender, RoutedEventArgs e)
        {

        }

        private void Item4CheckBoxGST_Checked(object sender, RoutedEventArgs e)
        {

        }

        private void ShipRadioButton_Checked(object sender, RoutedEventArgs e)
        {

        }

        private void PickupRadioButton_Checked(object sender, RoutedEventArgs e)
        {

        }

        private void CalculateButton_Click(object sender, RoutedEventArgs e)
        {


            //initiliaze the item values into zero
            double item1numberVal = 0;
            double item2numberVal = 0;
            double item3numberVal = 0;
            double item4numberVal = 0;

            double PSTcheck = 0.06;
            double pst1 = 0.00;
            double pst2 = 0.00;
            double pst3 = 0.00;
            double pst4 = 0.00;

            double GSTcheck = 0.05;
            double gst1 = 0.00;
            double gst2 = 0.00;
            double gst3 = 0.00;
            double gst4 = 0.00;

            double taxes;
            double subtotalComputation;
            double subtotalNumber, pstTotal, gstTotal;

            if (!Item1TextBox.Text.Equals("") && double.TryParse(Item1TextBox.Text, out item1numberVal))
            {
                item1numberVal = (item1numberVal >= 0) ? item1numberVal : 0;
                if (Item1CheckBoxPST.IsChecked == true)
                {
                    pst1 = item1numberVal * PSTcheck;
                }
                if (Item2CheckBoxPST.IsChecked == true)
                {
                    pst2 = item2numberVal * PSTcheck;
                }
                if (Item3CheckBoxPST.IsChecked == true)
                {
                    pst3 = item3numberVal * PSTcheck;
                }
                if (Item4CheckBoxPST.IsChecked == true)
                {
                    pst4 = item4numberVal * PSTcheck;
                }


                if (Item1CheckBoxGST.IsChecked == true)
                {
                    gst1 = item1numberVal * GSTcheck;
                }
                if (Item2CheckBoxGST.IsChecked == true)
                {
                    gst2 = item2numberVal * GSTcheck;
                }
                if (Item3CheckBoxGST.IsChecked == true)
                {
                    gst3 = item3numberVal * GSTcheck;
                }
                if (Item4CheckBoxGST.IsChecked == true)
                {
                    gst4 = item4numberVal * GSTcheck;
                }

                subtotalNumber = item1numberVal + item2numberVal + item3numberVal + item4numberVal;

                pstTotal = pst1 + pst2 + pst3 + pst4;    //PST total when checked on each item
                gstTotal = gst1 + gst2 + gst3 + gst4;    //GST total when checked on each item
                taxes = pstTotal + gstTotal;             //Total taxes of the PST and GST using the addition operator
                subtotalComputation = subtotalNumber + taxes;        //Total of all items and taxes
                PSTTextBox.Text = pstTotal.ToString("$0.00");
                GSTTextBox.Text = gstTotal.ToString("$0.00");


                if (!Item2TextBox.Text.Equals("") && double.TryParse(Item2TextBox.Text, out item2numberVal))
                {
                    item2numberVal = (item2numberVal >= 0) ? item2numberVal : 0;
                    if (Item1CheckBoxPST.IsChecked == true)
                    {
                        pst1 = item1numberVal * PSTcheck;
                    }
                    if (Item2CheckBoxPST.IsChecked == true)
                    {
                        pst2 = item2numberVal * PSTcheck;
                    }
                    if (Item3CheckBoxPST.IsChecked == true)
                    {
                        pst3 = item3numberVal * PSTcheck;
                    }
                    if (Item4CheckBoxPST.IsChecked == true)
                    {
                        pst4 = item4numberVal * PSTcheck;
                    }


                    if (Item1CheckBoxGST.IsChecked == true)
                    {
                        gst1 = item1numberVal * GSTcheck;
                    }
                    if (Item2CheckBoxGST.IsChecked == true)
                    {
                        gst2 = item2numberVal * GSTcheck;
                    }
                    if (Item3CheckBoxGST.IsChecked == true)
                    {
                        gst3 = item3numberVal * GSTcheck;
                    }
                    if (Item4CheckBoxGST.IsChecked == true)
                    {
                        gst4 = item4numberVal * GSTcheck;
                    }

                    subtotalNumber = item1numberVal + item2numberVal + item3numberVal + item4numberVal;

                    pstTotal = pst1 + pst2 + pst3 + pst4;    //PST total when checked on each item
                    gstTotal = gst1 + gst2 + gst3 + gst4;    //GST total when checked on each item
                    taxes = pstTotal + gstTotal;             //Total taxes of the PST and GST using the addition operator
                    subtotalComputation = subtotalNumber + taxes;        //Total of all items and taxes
                    PSTTextBox.Text = pstTotal.ToString("$0.00");
                    GSTTextBox.Text = gstTotal.ToString("$0.00");
                }


                if (!Item3TextBox.Text.Equals("") && double.TryParse(Item3TextBox.Text, out item3numberVal))
                {
                    item3numberVal = (item3numberVal >= 0) ? item3numberVal : 0;

                    if (Item1CheckBoxPST.IsChecked == true)
                    {
                        pst1 = item1numberVal * PSTcheck;
                    }
                    if (Item2CheckBoxPST.IsChecked == true)
                    {
                        pst2 = item2numberVal * PSTcheck;
                    }
                    if (Item3CheckBoxPST.IsChecked == true)
                    {
                        pst3 = item3numberVal * PSTcheck;
                    }
                    if (Item4CheckBoxPST.IsChecked == true)
                    {
                        pst4 = item4numberVal * PSTcheck;
                    }


                    if (Item1CheckBoxGST.IsChecked == true)
                    {
                        gst1 = item1numberVal * GSTcheck;
                    }
                    if (Item2CheckBoxGST.IsChecked == true)
                    {
                        gst2 = item2numberVal * GSTcheck;
                    }
                    if (Item3CheckBoxGST.IsChecked == true)
                    {
                        gst3 = item3numberVal * GSTcheck;
                    }
                    if (Item4CheckBoxGST.IsChecked == true)
                    {
                        gst4 = item4numberVal * GSTcheck;
                    }

                    subtotalNumber = item1numberVal + item2numberVal + item3numberVal + item4numberVal;

                    pstTotal = pst1 + pst2 + pst3 + pst4;    //PST total when checked on each item
                    gstTotal = gst1 + gst2 + gst3 + gst4;    //GST total when checked on each item
                    taxes = pstTotal + gstTotal;             //Total taxes of the PST and GST using the addition operator
                    subtotalComputation = subtotalNumber + taxes;        //Total of all items and taxes
                    PSTTextBox.Text = pstTotal.ToString("$0.00");
                    GSTTextBox.Text = gstTotal.ToString("$0.00");
                }


                if (!Item4TextBox.Text.Equals("") && double.TryParse(Item4TextBox.Text, out item4numberVal))
                {
                    item4numberVal = (item4numberVal >= 0) ? item4numberVal : 0;

                    if (Item1CheckBoxPST.IsChecked == true)
                    {
                        pst1 = item1numberVal * PSTcheck;
                    }
                    if (Item2CheckBoxPST.IsChecked == true)
                    {
                        pst2 = item2numberVal * PSTcheck;
                    }
                    if (Item3CheckBoxPST.IsChecked == true)
                    {
                        pst3 = item3numberVal * PSTcheck;
                    }
                    if (Item4CheckBoxPST.IsChecked == true)
                    {
                        pst4 = item4numberVal * PSTcheck;
                    }


                    if (Item1CheckBoxGST.IsChecked == true)
                    {
                        gst1 = item1numberVal * GSTcheck;
                    }
                    if (Item2CheckBoxGST.IsChecked == true)
                    {
                        gst2 = item2numberVal * GSTcheck;
                    }
                    if (Item3CheckBoxGST.IsChecked == true)
                    {
                        gst3 = item3numberVal * GSTcheck;
                    }
                    if (Item4CheckBoxGST.IsChecked == true)
                    {
                        gst4 = item4numberVal * GSTcheck;
                    }
                }

                subtotalNumber = item1numberVal + item2numberVal + item3numberVal + item4numberVal;

                pstTotal = pst1 + pst2 + pst3 + pst4;    //PST total when checked on each item
                gstTotal = gst1 + gst2 + gst3 + gst4;    //GST total when checked on each item
                taxes = pstTotal + gstTotal;             //Total taxes of the PST and GST using the addition operator
                subtotalComputation = subtotalNumber + taxes;        //Total of all items and taxes
                PSTTextBox.Text = pstTotal.ToString("$0.00");
                GSTTextBox.Text = gstTotal.ToString("$0.00");
                SubtotalTextBox.Text = subtotalComputation.ToString("$0.00");
           

                double addedShipping = 0.00;
                if (ShipRadioButton.IsChecked == true)
                {
                    addedShipping = subtotalComputation * 0.02;
                }
                ShippingTextBox.Text = addedShipping.ToString("$0.00");
                double totalCalculation = subtotalComputation + pstTotal + gstTotal + addedShipping;
                TotalTextBox.Text = totalCalculation.ToString("$0.00");

                double commissionRate = 0.00;
                if (totalCalculation <= 100)
                {
                    SalesCommissionTextbox.Background = Brushes.Black;
                    SalesCommissionTextbox.Foreground = Brushes.White;
                    commissionRate = totalCalculation * 0.035;
                }

                else if (totalCalculation >= 100 && totalCalculation <= 225)
                {
                    SalesCommissionTextbox.Background = Brushes.Blue;
                    SalesCommissionTextbox.Foreground = Brushes.White;
                    commissionRate = totalCalculation * 0.05;
                }
                else if (totalCalculation >= 225 && totalCalculation <= 500)
                {
                    SalesCommissionTextbox.Background = Brushes.Green;
                    SalesCommissionTextbox.Foreground = Brushes.White;
                    commissionRate = totalCalculation * 0.07;
                }
                else if (totalCalculation > 500)
                {
                    SalesCommissionTextbox.Background = Brushes.Red;
                    SalesCommissionTextbox.Foreground = Brushes.White;
                    commissionRate = totalCalculation * 0.11;
                }
                SalesCommissionTextbox.Text = commissionRate.ToString("$0.00");
            }
            else
            {
                MessageBox.Show("invalid");
            }
            }
        }
    }
