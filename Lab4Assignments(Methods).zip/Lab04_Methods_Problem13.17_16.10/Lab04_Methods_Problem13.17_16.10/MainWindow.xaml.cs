﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Lab04_Methods_Problem13._17_16._10
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }


        private void CalculateButton_Click_1(object sender, RoutedEventArgs e)
        {
            int LowerBound = Convert.ToInt32(LowerBoundTextBox.Text);
            int UpperBound = Convert.ToInt32(UpperBoundTextBox.Text);
            PrimeNumbersListBox.Items.Clear();
            PrimeNums(LowerBound, UpperBound);

        }
        private void PrimeNums(int LowerBound, int UpperBound)
        {
            string MessageError;
            if (LowerBound > UpperBound)
            {
                MessageError = "The lower bound must be less than upper bound!";
                MessageBox.Show(MessageError);
            }
            for (int i = LowerBound; i <= UpperBound; i++)
            {
                if (i == 1 || i == 0)
                    continue;

                LowerBound = 1;

                for (int a = 2; a <= i / 2; ++a)
                {
                    if (i % a == 0)
                    {
                        LowerBound = 0;
                        break;
                    }
                }
                if (LowerBound == 1)
                {
                    PrimeNumbersListBox.Items.Add(i);
                }
            }
        }
    }
}
