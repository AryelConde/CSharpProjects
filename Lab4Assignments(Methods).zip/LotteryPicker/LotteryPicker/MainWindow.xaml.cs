﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Transactions;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace LotteryPicker
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
            
        private void GenerateButton_Click(object sender, RoutedEventArgs e)
        {
            int ThreeLottery = 0, FourLottery = 0, FiveLottery = 0, FiveLotteryPlus = 0, AdditionalLottery = 0;
            GenerateRandomNumbers(ThreeLottery, FourLottery, FiveLottery, FiveLotteryPlus, AdditionalLottery);
        }
        private void GenerateRandomNumbers(int ThreeLottery, int FourLottery, int FiveLottery, int FiveLotteryPlus, int AdditionalLottery)
        {
            Random RandNum = new Random();
            ThreeLotteryTextBox.Text = "";
            FourLotteryTextBox.Text = "";
            FiveLotteryTextBox.Text = "";
            FiveLotteryPlusTextBox.Text = "";
            AdditionalLotteryTextBox.Text = "";
            for (int a = 0; a < 3; a++)
            {
                ThreeLottery = RandNum.Next(1, 10);
                ThreeLotteryTextBox.Text += ThreeLottery.ToString("00");
                ThreeLotteryTextBox.Text += " ";
            }
            for (int i = 0; i < 4; i++)
            {
                FourLottery = RandNum.Next(1, 10);
                FourLotteryTextBox.Text += FourLottery.ToString("00");
                FourLotteryTextBox.Text += " ";
            }
            for (int b = 0; b < 5; b++)
            {
                FiveLottery = RandNum.Next(1, 39);
                FiveLotteryTextBox.Text += FiveLottery.ToString("00");
                FiveLotteryTextBox.Text += " ";
            }
            for (int c = 0; c < 5; c++)
            {
                FiveLotteryPlus = RandNum.Next(1, 49);
                FiveLotteryPlusTextBox.Text += FiveLotteryPlus.ToString("00");
                FiveLotteryPlusTextBox.Text += " ";

                AdditionalLottery = RandNum.Next(1, 42);
                AdditionalLotteryTextBox.Text = AdditionalLottery.ToString("00");
            }
        }
    }
}
