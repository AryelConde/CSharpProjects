﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace _255MTBVillacampo
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();

        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            double LoanPrincipal, AnnualInterestRate, MonthlyInterest, MonthlyBudget, MonthlyPayment;
            int MonthsTerms;
            double DefaultValue = 0;
            string Column = "", Row = "", WithinBudget = "";

            LoanPrincipal = Convert.ToDouble(LoanAmountTextBox.Text);
            AnnualInterestRate = Convert.ToDouble(AnnualInterestTextBox.Text);
            MonthsTerms = Convert.ToInt16(MonthTermsTextBox.Text);
            MonthlyBudget = Convert.ToDouble(MonthlyPaymentBudgetTextBox.Text);


            Column = "Loan Term\t Monthly Payments\t Within Budget\n";
            Column += "========================================\n";


            OutputListBox.Items.Clear();

            int Months = 0;
            while (Months < MonthsTerms)
            {
                Months += MonthsTerms / 10;
                MonthlyInterest = AnnualInterestRate / 12 / 100;
                MonthlyPayment = LoanPrincipal * MonthlyInterest / (1 - Math.Pow(1 + MonthlyInterest, -Months)); ;

                if (MonthlyBudget > MonthlyPayment)
                {
                    WithinBudget = "Yes";
                    Row = $"{Months,-36}{MonthlyPayment,-36:C2}{WithinBudget}";
                    Column += Row + "\n";
                }
                else if (MonthlyBudget < MonthlyPayment)
                {
                    WithinBudget = "No";
                    Row = $"{Months,-36}{MonthlyPayment,-36:C2}{WithinBudget}";
                    Column += Row + "\n";
                }
            }
            OutputListBox.Items.Add(Column);
        }

        private void OutputListBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }
    }
}
