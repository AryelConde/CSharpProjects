﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Loops
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Calculate_Click(object sender, RoutedEventArgs e)
        {
            decimal StartingBalance, SavingsGoal, SavedEachMonth, AnnualInterest;
            decimal MonthlyInterestRate, MonthlyInterest;

            string OutputTable = "", OutputRow = "";

            StartingBalance = Convert.ToDecimal(StartingBalanceTextbox.Text);
            SavingsGoal = Convert.ToDecimal(SavingsGoalTextbox.Text);
            SavedEachMonth = Convert.ToDecimal(SavedEachMonthTextbox.Text);
            AnnualInterest = Convert.ToDecimal(AnnualInterestRateTextbox.Text);

            decimal CurrentBalance = StartingBalance;

            MonthlyInterestRate = AnnualInterest / 12 / 100;
            MonthlyInterestRate = AnnualInterest / (decimal)12.0 / 100;
            MonthlyInterestRate = AnnualInterest / Convert.ToDecimal(12.0) / 100;
            MonthlyInterestRate = AnnualInterest / 12.0m / 100;

            OutputTable = "Month\tInterest\tBalance\n";
            OutputTable += "=======================\n";

            int Month = 0;
            while(CurrentBalance < SavingsGoal)
            {
                Month++;

                MonthlyInterest = MonthlyInterestRate * CurrentBalance;
                CurrentBalance += MonthlyInterest;

                OutputRow = "(Month, -13)(MonthlyInterest, -13:C2)(CurrentBalance:C2)";
                OutputTable += OutputRow + "\n";
            }

            OutputTextBlock.Text = OutputTable;

        }

        private void StartingBalanceTextbox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void SavingsGoalTextbox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void SavedEachMonthTextbox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void AnnualInterestRateTextbox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }
    }
}
